# Notice

“StratX” and “RouteFi” are trademarks of their respective owners. This documentation describes technology concepts at a high level and omits sensitive details. Patent(s) pending; no proprietary algorithms are disclosed.
