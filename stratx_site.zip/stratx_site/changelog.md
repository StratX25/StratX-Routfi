---
layout: default
title: Changelog
nav_order: 11
---

# Changelog

## 2025-08-17

- Initial release of the public informational site for StratX and RouteFi.
- Added pages for Home, StratX, RouteFi, Architecture, Use Cases, Benefits, FAQ, News, Legal, Contact, Press Kit, and Changelog.
- Included two SVG diagrams, logos, social images, favicons, and custom CSS.
- Added three blog posts and a boilerplate copy deck.
