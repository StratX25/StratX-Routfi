---
layout: default
title: Intellectual Property Notice
parent: Legal
nav_order: 3
---

# Intellectual Property Notice

“StratX” and “RouteFi” are trademarks of their respective owners. All rights reserved. Certain technologies described may be protected by patent(s) pending. No proprietary algorithms or unpublished details are disclosed on this site.
