---
layout: default
title: Privacy Policy
parent: Legal
nav_order: 1
---

# Privacy Policy

We value your privacy. This site does not collect personal data by default. There are no cookies, analytics, or trackers enabled. If we add an optional, privacy‑respecting analytics tool in the future, we will update this policy and provide a clear opt‑out.

We process only the information necessary to display the site and deliver content. If you contact us by email, we will use your information solely to respond to your inquiry.
